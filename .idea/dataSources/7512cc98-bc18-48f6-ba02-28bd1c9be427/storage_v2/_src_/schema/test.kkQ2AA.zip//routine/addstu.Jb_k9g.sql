create function addstu(b VARCHAR(50)) returns INT(10)
BEGIN
	#Routine body goes here...
insert into tb_student(student_name,sex) values(a||'AA',b);
END;

