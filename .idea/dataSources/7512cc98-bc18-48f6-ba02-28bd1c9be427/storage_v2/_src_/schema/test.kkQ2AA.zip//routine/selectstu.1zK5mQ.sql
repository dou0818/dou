create procedure selectstu()
BEGIN
	#Routine body goes here...
select * from tb_student;
END;

