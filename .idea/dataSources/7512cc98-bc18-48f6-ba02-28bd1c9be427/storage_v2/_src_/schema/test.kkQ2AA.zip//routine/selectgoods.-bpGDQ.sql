create function selectgoods() returns VARCHAR(50)
BEGIN
	select id,goodsname,myorderid from goods where goodsname like a;

END;

