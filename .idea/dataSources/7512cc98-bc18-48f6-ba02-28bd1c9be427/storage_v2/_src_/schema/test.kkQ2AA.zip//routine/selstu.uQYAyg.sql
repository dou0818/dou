create procedure selstu()
BEGIN
	#Routine body goes here...
select * from tb_student;
END;

