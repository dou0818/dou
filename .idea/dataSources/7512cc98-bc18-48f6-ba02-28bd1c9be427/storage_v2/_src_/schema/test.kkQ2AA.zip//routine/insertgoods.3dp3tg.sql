create function insertgoods(b INT(10)) returns VARCHAR(50)
BEGIN
	insert into goods(goodsname,myorderid) values(a,b);

END;

